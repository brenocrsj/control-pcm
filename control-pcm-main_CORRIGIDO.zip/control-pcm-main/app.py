import os
import sqlite3
from datetime import datetime
from functools import wraps
from io import BytesIO

import pandas as pd
from flask import (
    Flask,
    Response,
    flash,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from flask_bcrypt import Bcrypt
from fpdf import FPDF


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-secret-change-me")
    app.config["DATABASE_PATH"] = os.getenv("DATABASE_PATH", "refeitorio.db")
    app.config["FLASK_DEBUG"] = os.getenv("FLASK_DEBUG", "0") == "1"

    bcrypt = Bcrypt(app)

    def get_db_connection():
        conn = sqlite3.connect(app.config["DATABASE_PATH"])
        conn.row_factory = sqlite3.Row
        return conn

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not session.get("admin_logged_in"):
                flash("Acesso negado. Por favor, faça login.", "warning")
                return redirect(url_for("home"))
            return view(*args, **kwargs)

        return wrapped

    @app.route("/")
    def home():
        return render_template("acesso.html")

    @app.route("/acesso_refeitorio", methods=["POST"])
    def acesso_refeitorio():
        matricula = request.form.get("matricula", "").strip()
        if not matricula:
            return jsonify({"status": "error", "message": "Informe a matrícula."}), 400

        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT nome FROM colaboradores WHERE matricula = ?", (matricula,))
            colaborador = cursor.fetchone()

            if not colaborador:
                return jsonify({"status": "error", "message": "Matrícula não encontrada."}), 404

            data_hora_atual = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor.execute(
                "INSERT INTO registros (matricula, data_hora) VALUES (?, ?)",
                (matricula, data_hora_atual),
            )
            conn.commit()
            return jsonify({"status": "success", "nome": colaborador["nome"]})
        except sqlite3.Error as e:
            return jsonify({"status": "error", "message": f"Ocorreu um erro: {e}"}), 500
        finally:
            conn.close()

    @app.route("/login_admin", methods=["POST"])
    def login_admin():
        senha = request.form.get("senha", "")
        conn = get_db_connection()
        try:
            admin = conn.execute(
                "SELECT senha_hash FROM colaboradores WHERE matricula = ? AND nivel_acesso = ?",
                ("admin", "admin"),
            ).fetchone()

            if admin and admin["senha_hash"] and bcrypt.check_password_hash(admin["senha_hash"], senha):
                session["admin_logged_in"] = True
                return redirect(url_for("admin_cadastro"))

            flash("Senha incorreta. Tente novamente.", "danger")
            return redirect(url_for("home"))
        finally:
            conn.close()

    @app.route("/logout")
    def logout():
        session.pop("admin_logged_in", None)
        return redirect(url_for("home"))

    @app.route("/admin")
    @login_required
    def admin_cadastro():
        return render_template("admin_cadastro.html")

    @app.route("/cadastrar", methods=["POST"])
    @login_required
    def cadastrar_colaborador():
        matricula = request.form.get("matricula", "").strip()
        nome = request.form.get("nome", "").strip()
        funcao = request.form.get("funcao", "").strip()
        area = request.form.get("area", "").strip()

        if not matricula or not nome:
            flash("Matrícula e nome são obrigatórios.", "danger")
            return redirect(url_for("admin_cadastro"))

        conn = get_db_connection()
        try:
            conn.execute(
                "INSERT INTO colaboradores (matricula, nome, funcao, area) VALUES (?, ?, ?, ?)",
                (matricula, nome, funcao, area),
            )
            conn.commit()
            flash("Colaborador cadastrado com sucesso.", "success")
        except sqlite3.IntegrityError:
            flash(f'Erro: A matrícula "{matricula}" já está cadastrada.', "danger")
        finally:
            conn.close()

        return redirect(url_for("admin_cadastro"))

    @app.route("/relatorio")
    @login_required
    def relatorio_completo():
        data_inicio = request.args.get("data_inicio")
        data_fim = request.args.get("data_fim")

        query = """
            SELECT
                registros.data_hora,
                registros.matricula,
                colaboradores.nome,
                colaboradores.funcao,
                colaboradores.area
            FROM registros
            JOIN colaboradores ON registros.matricula = colaboradores.matricula
        """
        params = []

        if data_inicio or data_fim:
            query += " WHERE "
            if data_inicio and not data_fim:
                query += " registros.data_hora >= ?"
                params.append(data_inicio)
            elif not data_inicio and data_fim:
                query += " registros.data_hora <= ?"
                params.append(data_fim)
            else:
                query += " registros.data_hora BETWEEN ? AND ?"
                params.extend([data_inicio, data_fim])

        query += " ORDER BY registros.data_hora DESC"

        conn = get_db_connection()
        try:
            registros = conn.execute(query, params).fetchall()
        finally:
            conn.close()

        return render_template("relatorio.html", registros=registros)

    @app.route("/exportar/excel")
    @login_required
    def exportar_excel():
        conn = get_db_connection()
        try:
            registros = conn.execute(
                """
                SELECT
                    registros.data_hora,
                    registros.matricula,
                    colaboradores.nome,
                    colaboradores.funcao,
                    colaboradores.area
                FROM registros
                JOIN colaboradores ON registros.matricula = colaboradores.matricula
                ORDER BY registros.data_hora DESC
                """
            ).fetchall()
        finally:
            conn.close()

        df = pd.DataFrame(registros, columns=["Data e Hora", "Matrícula", "Nome", "Função", "Área"])

        output = BytesIO()
        with pd.ExcelWriter(output, engine="xlsxwriter") as writer:
            df.to_excel(writer, index=False, sheet_name="Relatório")
        output.seek(0)

        return Response(
            output.getvalue(),
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment;filename=relatorio_refeitorio.xlsx"},
        )

    @app.route("/exportar/pdf")
    @login_required
    def exportar_pdf():
        conn = get_db_connection()
        try:
            registros = conn.execute(
                """
                SELECT
                    registros.data_hora,
                    registros.matricula,
                    colaboradores.nome,
                    colaboradores.funcao,
                    colaboradores.area
                FROM registros
                JOIN colaboradores ON registros.matricula = colaboradores.matricula
                ORDER BY registros.data_hora DESC
                """
            ).fetchall()
        finally:
            conn.close()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        pdf.cell(200, 10, txt="Relatório de Acessos ao Refeitório", ln=True, align="C")
        pdf.ln(10)

        pdf.set_font("Arial", size=10, style="B")
        headers = ["Data e Hora", "Matrícula", "Nome", "Função", "Área"]
        col_widths = [40, 25, 40, 30, 30]
        for i, header in enumerate(headers):
            pdf.cell(col_widths[i], 10, header, border=1)
        pdf.ln()

        pdf.set_font("Arial", size=10)
        for row in registros:
            pdf.cell(col_widths[0], 10, str(row["data_hora"]), border=1)
            pdf.cell(col_widths[1], 10, str(row["matricula"]), border=1)
            pdf.cell(col_widths[2], 10, str(row["nome"]), border=1)
            pdf.cell(col_widths[3], 10, str(row["funcao"]), border=1)
            pdf.cell(col_widths[4], 10, str(row["area"]), border=1)
            pdf.ln()

        return Response(
            pdf.output(dest="S").encode("latin-1"),
            mimetype="application/pdf",
            headers={"Content-Disposition": "attachment;filename=relatorio_refeitorio.pdf"},
        )

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=app.config["FLASK_DEBUG"])
