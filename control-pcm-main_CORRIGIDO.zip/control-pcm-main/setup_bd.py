import os
import sqlite3
from flask_bcrypt import Bcrypt

bcrypt = Bcrypt()

DB_PATH = os.getenv("DATABASE_PATH", "refeitorio.db")
# DICA: troque a senha padrão antes de subir para produção
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "123456")


def criar_banco_de_dados(db_path: str = DB_PATH) -> None:
    """Cria/configura o banco SQLite usado pela aplicação."""
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS colaboradores (
                matricula TEXT PRIMARY KEY,
                nome TEXT NOT NULL,
                funcao TEXT,
                area TEXT,
                senha_hash TEXT,
                nivel_acesso TEXT NOT NULL DEFAULT 'colaborador'
            )
            """
        )

        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS registros (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                matricula TEXT NOT NULL,
                data_hora TEXT NOT NULL,
                FOREIGN KEY (matricula) REFERENCES colaboradores(matricula)
            )
            """
        )

        # Admin padrão (troque a senha via env ADMIN_PASSWORD)
        senha_admin_hash = bcrypt.generate_password_hash(ADMIN_PASSWORD).decode("utf-8")
        cursor.execute(
            """
            INSERT OR IGNORE INTO colaboradores (matricula, nome, nivel_acesso, senha_hash)
            VALUES (?, ?, ?, ?)
            """,
            ("admin", "Administrador", "admin", senha_admin_hash),
        )

        conn.commit()
        print(f"Banco de dados '{db_path}' configurado com sucesso!")
    finally:
        conn.close()


if __name__ == "__main__":
    criar_banco_de_dados()
