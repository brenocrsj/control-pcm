# control-pcm

Aplicação web (Flask + SQLite) para **controle de acesso ao refeitório** com:
- Registro rápido por matrícula (tela de acesso)
- Área administrativa (cadastro de colaboradores)
- Relatório com filtro por data
- Exportação para **Excel** e **PDF**

## Requisitos
- Python 3.11+

## Como rodar (local)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt

# cria o banco (apenas na primeira vez)
python setup_bd.py

# inicia
python app.py
```

Abra: http://127.0.0.1:5000

## Variáveis de ambiente
Crie um `.env` (use `.env.example` como base):
- `SECRET_KEY` (obrigatório em produção)
- `DATABASE_PATH` (default: `refeitorio.db`)
- `FLASK_DEBUG` (default: `0`)

## Produção (Gunicorn)
```bash
gunicorn app:app
```

## Segurança (admin)
O usuário `admin` é criado pelo `setup_bd.py`.
Troque a senha alterando o valor no script antes de rodar, ou atualize o hash no banco.
